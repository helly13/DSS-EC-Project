package com.example.sandburg.Constants;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class MenuData {

    @SerializedName("Item_name")
    public String Item_name;



}
