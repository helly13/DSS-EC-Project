package com.example.sandburg;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

public class LA1 extends AppCompatActivity {

    public FragmentActivity getActivity1() {
        return this;
    }
}
